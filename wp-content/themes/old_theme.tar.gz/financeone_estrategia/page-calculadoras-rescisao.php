<?php
/*
 Template Name: Calculadoras 
 */
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

get_header(); ?>
	<section id="principal" class="container-fluid">
		<div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
			<div class="row">
				<h1><?php the_title(); ?></h1>
			</div>
			<div class="row">
			<?php
				global $post;
    			$post_slug = $post->post_name;
                
				if ($post_slug == 'calculo-de-rescisao-trabalhista'){
					if (isset($_POST['bt_submit'])) echo Calculadoras::Resultado();
					else echo Calculadoras::formRescisao();
                } elseif ($post_slug == 'calculo-de-salario-liquido') {
                    if (isset($_POST['acao']) && ($_POST['acao'] == 'calcSalarioLiquido')) echo Calculadoras::ResultadoSalarioLiquido();
                    else echo Calculadoras::formSalarioLiquido();
                } elseif ($post_slug == 'calculo-de-hora-extra') {
                    if (isset($_POST['acao']) && ($_POST['acao'] == 'calcHoraExtra')) echo Calculadoras::ResultadoHoraExtra();
                    else echo Calculadoras::formHoraExtra();
				} elseif ($post_slug == 'calculo-de-rescisao-antecipada') {
                    if (isset($_POST['bt_submit'])) echo Calculadoras::ResultadoRescisaoAntecipada();
                    else echo Calculadoras::formRescisaoAntecipada();
                }
				
				// echo Calculadoras::init();
			?>
			</div>
		</div>
		<?php get_template_part('template-parts/left'); ?>
		<?php get_template_part('template-parts/right'); ?>
	</section>
<?php
get_footer();
