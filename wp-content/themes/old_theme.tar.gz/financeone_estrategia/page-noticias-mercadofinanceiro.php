<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

 /*
 Template Name: Pagina noticias mercado financeiro
 */

get_header(); ?>
<section id="principal" class="container-fluid">
	<div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
		<div class="row">
			<h1><?php the_title(); ?></h1>
		</div>

                <div id="box-noticia-resumida">
                <?php
                        $query = new WP_Query(
					array (
						'posts_per_page' => 20,
						'category_name' => 'noticias-mercado-financeiro',
						'paged' => get_query_var( 'page' ),
					)
				);

                        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();
				get_template_part('template-parts/postBox');
                	endwhile; else :
		?>
                        <p><?php esc_html_e( 'Nada para mostar aqui.' ); ?></p>
                <?php endif; wp_reset_query();  ?>
                </div>

		<div class="row">
			<a href="<?php echo get_site_url(); ?>/noticias/mercado-financeiro/<?php echo (get_query_var( 'page' ) == 0  ? 2 : get_query_var( 'page' )); ?>" class="btn-silver">ver mais noticias</a>
		</div>
	</div>

	<?php
		get_template_part('template-parts/left');
		get_template_part('template-parts/right');
	?>
</section>
<?php get_footer(); ?>
