<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

get_header(); ?>
<section id="principal" class="container-fluid">
        <div class="col-md-6 col-xs-12 col-md-push-3" id="ultimas-noticias">
                <div class="row">
                        <h1 class='entry-title'><?php the_archive_title(); ?></h1>
                </div>

                <div id="box-noticia-resumida">
                <?php
                        if ( have_posts() ) : while ( have_posts() ) : the_post();
				get_template_part('template-parts/postBox');
                        endwhile;
                                the_posts_navigation();
                        else :
                                get_template_part( 'template-parts/content', 'none' );
                        endif;
                ?>
                </div>

                <?php
                        get_template_part('template-parts/categoryBoard');
                ?>
        </div>

        <?php
                get_template_part('template-parts/left');
                get_template_part('template-parts/right');
        ?>
</section>
<?php get_footer(); ?>
