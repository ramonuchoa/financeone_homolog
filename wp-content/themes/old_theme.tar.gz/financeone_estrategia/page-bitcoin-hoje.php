<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 *
 * Template Name: Bitcoin Hoje
 */

get_header(); ?>

<section id="principal" class="container-fluid">
        <div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
                <div class="row">
                        <h1><?php the_title(); ?></h1>
                </div>

                <div class="row dolar-hoje">1 Bitcoin vale R$<?php echo clQuote("BTC"); ?> hoje</div>

                <div class="row">
                        <p><strong>Finance One</strong> tem a Cotação do Bitcoin sempre atualizada para que você tome as melhores decisões.</p>
                        <p>O <strong>valor do Bitcoin</strong> hoje é de caráter informativo, sendo atualizado com informações da <strong>Foxbit</strong>.</p>
                </div>

                <div class="row">
                        <h2>O que é Bitcoin?</h2>
                        <p>O <strong>Bitcoin</strong> (também conhecida pela sigla BTC) é uma moeda virtual (ou digital). Significa moeda bit, sendo que coin é moeda em inglês, e bit corresponde ao dígito binário. Ela não existe fisicamente, é totalmente virtual.</p>
                </div>

                <div class="row">
                        <h2>Como investir em Bitcoin?</h2>

                        <p>Bitcoins são recomendados apenas para investidores extremamente arrojados, que procuram diversificar investimentos e topam encarar a alta volatilidade para experimentar a tecnologia. É possível comprar uma fração de um bitcoin com 50 reais. As corretoras especializadas cobram uma taxa que varia de 0,3% a 1% sobre o valor da operação.</p>
                        <p>A operação de compra e venda de bitcoins é muito parecida com o mecanismo de ações. Comece com pequenos valores para sentir se você suporta a volatilidade. Ganhos com a venda de bitcoins acima de R$ 35 mil sofrem tributação de 15% e precisam ser declarados no Imposto de Renda.</p>
		</div>

		 <div class="row">
                        <h2>Hist&oacute;rico de cota&ccedil&otilde;es do  Bitcoin</h2>

                        <table class="table">
                                <tr>
                                        <th>Data</th>
                                        <th>Valor</th>
                                </tr>
                                <?php echo clQuoteTable('BTC'); ?>
                        </table>
                </div>

                <div class="row">
                        <h2>Regulação do Bitcoin</h2>

                        <p>Do ponto de vista tecnológico, as moedas digitais têm um potencial revolucionário como meio de pagamento e podem impactar o mundo assim como a internet.</p>
                        <p>Os Bitcoins ainda não são reguladas pelo Banco Central e pela Comissão de Valores Mobiliários (CVM). Isso significa que ninguém controla os bitcoins e que não há garantias para o pequeno investidor.</p>
                </div>

                <div class="row">
                        <?php
                                $numerosParaCalcular = array(
                                        array('numero' => 1, 'texto'=>'1 Bitcoin'),
                                        array('numero' => 2, 'texto' => '2 Bitcoins'),
                                        array('numero' => 5, 'texto' => '5 Bitcoins'),
                                        array('numero' => 10, 'texto' => '10 Bitcoins'),
                                        array('numero' => 25, 'texto' => '25 Bitcoins'),
                                        array('numero' => 50, 'texto' => '50 Bitcoins'),
                                        array('numero' => 100, 'texto' => '100 Bitcoins'),
                                        array('numero' => 500, 'texto' => '500 Bitcoins'),
                                        array('numero' => 1000, 'texto' => '1.000 Bitcoins'),
                                        array('numero' => 10000, 'texto' => '10.000 Bitcoins'),
                                );

                                $value = floatval(str_replace(",", "", clQuote('BTC'))) * 1000;
                        ?>

			<h2>Tabela de Valores em Bitcoin convertidos em Real</h2>

			<table class="table">
                                <tr>
                                        <th>Bitcoin</th>
                                        <th>Real</th>
                                </tr>

                                <?php foreach ($numerosParaCalcular as $key => $numero) :?>
                                <tr>
                                        <td><?php echo $numero['texto']; ?></td>
                                        <td><?php echo "R$". number_format(($numero['numero'] * $value), 2, ',', '.');  ?></td>
                                </tr>
                                <?php endforeach; ?>
                        </table>
                </div>

        </div>

        <?php
                get_template_part('template-parts/left');
                get_template_part('template-parts/right');
        ?>
</section>

<?php get_footer(); ?>
