<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package financeone
 */
        $pageList = [
                'conversor-de-moedas',
                'dolar-hoje',
                'euro-hoje',
                'bitcoin-hoje',
                'cotacoes-do-dolar',
                'cotacoes-do-euro'
        ];
?>
<footer class="container-fluid reset-padding">
        <?php echo do_shortcode('[the_ad id="72475"]'); ?>
	<div id="footer-top"></div>
        <div id="footer-bottom">
                <div class="col-md-9">
                        <ul class="MenuFooter">
                                <li><h2>Moedas</h2></li>
                                <li><a href="<?php echo site_url(); ?>/moedas/conversor-de-moedas/">Conversor de Moedas</a></li>
                                <li><a href="<?php echo site_url(); ?>/moedas/cotacoes-do-dolar/">Cota&ccedil;&otilde;es do D&oacute;lar</a></li>
                                <li><a href="<?php echo site_url(); ?>/moedas/cotacoes-do-euro/">Cota&ccedil;&otilde;es do Euro</a></li>
                                <li><a href="<?php echo site_url(); ?>/moedas/cotacoes-do-real-e-outras-moedas/">Cota&ccedil;&otilde;es do Real e outras Moedas</a></li>
                                <li><a href="<?php echo site_url(); ?>/moedas/historico-de-moedas-brasileiras/">Hist&oacute;rico de Moedas Brasileiras</a></li>
                        </ul>

                        <ul class="MenuFooter">
                                <li><h2>Investimentos</h2></li>
                                <li><a href="<?php echo site_url(); ?>/investimentos/rendimento-e-historico-da-poupanca/">Rendimento e Hist&oacute;rico da Poupan&ccedil;a</a></li>
                        </ul>

                        <ul class="MenuFooter">
                                <li><h2>Not&iacute;cias</h2></li>
                                <li><a href="<?php echo site_url(); ?>/noticias/mercado-cambial/">Mercado Cambial</a></li>
                                <li><a href="<?php echo site_url(); ?>/noticias/mercado-financeiro/">Mercado Financeiro</a></li>
                                <li><a href="<?php echo site_url(); ?>/noticias/economia/">Economia</a></li>
                        </ul>

                        <ul class="MenuFooter">
                                <li><h2>Acessibilidade</h2></li>
                                <li><a href="<?php echo site_url(); ?>/contato/">Contato</a></li>
                                <li><a href="<?php echo site_url(); ?>/quem-somos/">Quem somos</a></li>
                        </ul>
                </div>
		<div class="col-md-3 redes-sociais-e-parceiros col-xs-12">
                        <h2><span class="underscore">Redes</span> Sociais</h2>

                        <ul class="social-icons">
                                <li><a href="https://www.instagram.com/financeonebr/" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/img/social-icons/instagramfooter.png" alt=""></a></li>
                                <li><a href="https://www.facebook.com/FinanceOneBr" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/img/social-icons/facebook-btn.png" alt=""></a></li>
                        </ul>
                </div>
        </div>
</footer>

<?php wp_footer(); ?>

<script src="<?php bloginfo('template_directory'); ?>/js/default.js"></script>

<!-- Start Afilio Dynamic Ads -->
<script>
	window.adsbydynaton = {
		site_id: 47572,
		aff_id: 40551,
	};

	window.dynatonOptions = {
		app_id: 'financeone'
	}
</script>	
<script async src="https://s3-sa-east-1.amazonaws.com/static.dynaton.com.br/adsbydynaton.min.js" async="1"></script>
<!-- End Afilio Dynamic Ads --> 

<script type='text/javascript' src='https://financeone.com.br/wp-includes/js/dynaton_financeone.js?a=1'></script>
<?php if ( is_page($pageList) ) : ?>
        <script type="text/javascript">
                (function(){
                        window.onload = function() {
                                var redirectUrl = encodeURIComponent("http://v2.afilio.com.br/tracker.php?banid=4436710&campid=48220;2645&siteid=51514");
                                var baseTwCalcUrl = "https://transferwise.com/widget/calculator";
                                var twIframeUrl = baseTwCalcUrl
                                                + "?sourceCountryCode=BR"
                                                + "&targetCountryCode=US"
                                                + "&amount=1000"
                                                + "&cta=Transferir agora"
                                                + "&hideCta=false"
                                                + "&hideDetails=false"
                                                + "&theme=light"
                                                + "&redirectUrl=" + redirectUrl
                                                + "&lang=pt_br"

                                var twIframe = document.createElement('iframe');
                                twIframe.frameBorder=0;
                                twIframe.width="100%";
				twIframe.height="450px";
                                twIframe.id="tw-calc";
                                twIframe.scrolling = "no";
                                twIframe.setAttribute('allowtransparency', 'true');
                                twIframe.setAttribute("src", twIframeUrl);
                                document.getElementById("tw-calc-widget").appendChild(twIframe);
                        };
                }) ();
        </script>
<?php endif; ?>
</body>
</html>
