<?php
/**
 * financeone functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package financeone
 */

if ( ! function_exists( 'financeone_setup' ) ) :
        /**
         * Sets up theme defaults and registers support for various WordPress features.
         *
         * Note that this function is hooked into the after_setup_theme hook, which
         * runs before the init hook. The init hook is too late for some features, such
         * as indicating support for post thumbnails.
         */

        function selectDePaises($id, $options, $selected = null) {
                $html = '<select name="'.$id.'" id="'.$id.'">';
                $html .= '<option>SELECIONE</option>';

                foreach ($options as $value => $label) {
                        $s      = ($selected && $value == $selected) ? 'selected="selected"' : '';
                        $html  .= '<option value="'.$label->pais.'" data-code="'.$label->code.'" '.$s.'>'.$label->pais.'('.$label->nome.')</option>';
                }

                $html .= '</select>';
                return $html;
        }

function indices_mundiais($indice) {
        global $wpdb;
        $indice = $wpdb->get_row( "select fechamento from indices_mundiais WHERE indicador = '$indice' ORDER BY data DESC LIMIT 1" );
        return $indice;
}       

function indicadores_economicos($indice) {
        global $wpdb;
        $indice = $wpdb->get_row( "select fechamento from indicadores_economicos WHERE indicador = '$indice' ORDER BY data DESC LIMIT 1" );
        return $indice;
}

function conversao($valor,$from,$to) {
        global $wpdb;

        $origem = [];
        $destino = [];

        $origem['pais']   = $from;
        $destino['pais']  = $to;
        $sql = "SELECT MN.code, MN.pais, MN.nome, MD.valor, MD.data FROM moedas_nome MN LEFT JOIN moedas_dado MD on MD.code = MN.code WHERE MN.pais LIKE '".$origem['pais']."' ORDER BY MD.data DESC LIMIT 0 , 1";
        $moeda_from = $wpdb->get_row($sql);

        $origem['pais'] = ucwords(strtolower($origem['pais']));
        $origem['code'] = $moeda_from->code;
        $origem['nome'] = ucwords(strtolower($moeda_from->nome));
        $origem['data'] = $moeda_from->data;
        $origem['cota'] = $moeda_from->valor;


	# Se a conversão for de dólar, usar os dados da tabela atualizada dados_dolar. Os dados da tabela moedas_dado 
	# correspondem ao dólar PTAX, que ele puxa de um CSV do site do Banco Central do Brasil
//	if (($from == 'ESTADOS UNIDOS') || ($to == 'ESTADOS UNIDOS')){
//		$sql 	= "SELECT venda FROM finance_one.dados_dolar WHERE tipo = 'comercial' ORDER BY data DESC LIMIT 0,1";
//		$dolar 	= $wpdb->get_row($sql);
//	}
//
//	if ($from == 'ESTADOS UNIDOS'){
//		$origem['cota'] = $dolar->venda;
//	}
//
//	if (($from == 'REINO UNIDO') || ($to == 'REINO UNIDO')){
//		$sql 	= "SELECT venda FROM finance_one.dados_libra WHERE tipo = 'comercial' ORDER BY data DESC LIMIT 0,1";
//		$libra 	= $wpdb->get_row($sql);
//	}
//
//	if ($from == 'REINO UNIDO'){
//		$origem['cota'] = $libra->venda;
//	}
//	if (($from == 'EURO') || ($to == 'EURO')){
//		$sql 	= "SELECT venda FROM finance_one.dados_euro WHERE tipo = 'comercial' ORDER BY data DESC LIMIT 0,1";
//		$euro 	= $wpdb->get_row($sql);
//	}
//
//	if ($from == 'EURO'){
//		$origem['cota'] = $euro->venda;
//	}

	switch ($from) {
                case 'ESTADOS UNIDOS':
                        $origem['cota'] = clQuote('USD');
                        break;
                case 'REINO UNIDO':
                        $origem['cota'] = clQuote('GBP');
                        break;
                case 'EURO':
                        $origem['cota'] = clQuote('EUR');
                        break;
        }

	$moeda_to = $wpdb->get_row( "SELECT MN.code, MN.pais, MN.nome, MD.valor, MD.data FROM moedas_nome MN LEFT JOIN moedas_dado MD on MD.code = MN.code WHERE MN.pais LIKE '".$destino['pais']."' ORDER BY MD.data DESC LIMIT 0 , 1" );

	$destino['pais'] = ucwords(strtolower($destino['pais']));
	$destino['code'] = $moeda_to->code;
	$destino['nome'] = ucwords(strtolower($moeda_to->nome));
	$destino['data'] = $moeda_to->data;
	$destino['cota'] = $moeda_to->valor;

//	if ($to == 'ESTADOS UNIDOS'){
//		$destino['cota'] = $dolar->venda;
//	}
//
//	if ($to == 'REINO UNIDO'){
//		$destino['cota'] = $libra->venda;
//	}
//	if ($to == 'EURO'){
//		$destino['cota'] = $euro->venda;
//	}

	switch ($to) {
                case 'ESTADOS UNIDOS':
                        $destino['cota'] = clQuote('USD');
                        break;
                case 'REINO UNIDO':
                        $destino['cota'] = clQuote('GBP');
                        break;
                case 'EURO':
                        $destino['cota'] = clQuote('EUR');
                        break;
        }

        if (!$valor) $valor = 1;

        //Prepara para calculo
        $valor            = preg_replace("/,/",".",$valor);
        $origem['cota']   = preg_replace("/,/",".",$origem['cota']);
        $destino['cota']  = preg_replace("/,/",".",$destino['cota']);

        if ($origem['code'] == 'BRL') {
                $resultado = $valor / $destino['cota'];
        } else if ($destino['code'] == 'BRL') {
                $resultado = $valor * $origem['cota'];
        } else {
                $resultado = ($valor / $destino['cota']) * $origem['cota'];
        }

        $resultado = number_format($resultado, 2, ',', '.');
        return $resultado;
}

function get_moedas($principais = false, $order = 'pais', $conv = 'de') {
        global $wpdb;
        $sql = "SELECT DISTINCT code,nome,pais FROM moedas_nome ORDER BY {$order}";
        $moedas = $wpdb->get_results($sql);
        $moedasEditadas = array();
        $moedasDestaque = array();

        foreach ($moedas as $key => $moeda) {
                if(($moeda->pais != 'BRASIL') AND ($moeda->pais != 'ESTADOS UNIDOS') AND ($moeda->pais != 'EURO')) {
                        $moedasEditadas[] = $moeda;
                } else {
                        $moedasDestaque[] = $moeda;
                }
        }

        array_unshift($moedasEditadas,$moedasDestaque[0],$moedasDestaque[1],$moedasDestaque[2]);
        return $moedasEditadas;
}

function financeone_setup() {
        load_theme_textdomain( 'financeone', get_template_directory() . '/languages' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );

        register_nav_menus( array(
                                'menu-1' => esc_html__( 'Primary', 'financeone' ),
                                ) );

        add_theme_support( 'html5', array(
                                'search-form',
                                'comment-form',
                                'comment-list',
                                'gallery',
                                'caption',
                                ) );

        add_theme_support( 'custom-background', apply_filters( 'financeone_custom_background_args', array(
                                        'default-color' => 'ffffff',
                                        'default-image' => '',
                                        ) ) );

        add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'financeone_setup' );

add_filter('redirect_canonical', function($redirect_url, $requested_url) {
                if($requested_url == home_url('index.php')) {
                return '';
                }
                }, 10, 2);

function financeone_content_width() {
        $GLOBALS['content_width'] = apply_filters( 'financeone_content_width', 640 );
}
add_action( 'after_setup_theme', 'financeone_content_width', 0 );

function financeone_widgets_init() {
        register_sidebar( array(
                                'name'          => esc_html__( 'Sidebar', 'financeone' ),
                                'id'            => 'sidebar-1',
                                'description'   => esc_html__( 'Add widgets here.', 'financeone' ),
                                'before_widget' => '<section id="%1$s" class="widget %2$s">',
                                'after_widget'  => '</section>',
                                'before_title'  => '<h2 class="widget-title">',
                                'after_title'   => '</h2>',
                               ) );
}
add_action( 'widgets_init', 'financeone_widgets_init' );

function financeone_scripts() {
        wp_enqueue_style( 'financeone-style', get_stylesheet_uri() );
        wp_enqueue_script( 'financeone-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
        wp_enqueue_script( 'financeone-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
                wp_enqueue_script( 'comment-reply' );
        }
}
add_action( 'wp_enqueue_scripts', 'financeone_scripts' );

require get_template_directory() . '/inc/custom-header.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/jetpack.php';

add_image_size( 'destaque-home',600,320,array( 'top', 'center' ));
add_image_size( 'destaque-home-mini',283,120,array( 'top', 'center' ));
add_image_size( 'destaque-home-ultimas',84,83,array( 'top', 'center' ));
add_image_size( 'noticia-interna',930,494,array( 'top', 'center' ));

function postagens($args,$contentFunc){
        $my_query = null;
        $my_query = new WP_Query($args);
        if( $my_query->have_posts() ) {
                while ($my_query->have_posts()) : $my_query->the_post();
                $contentFunc($my_query);
                endwhile;
        }
        wp_reset_query();

}

function debug($value){
        print_r('<pre>');
        print_r($value);
        print_r('</pre>');
}

function add_query_vars_filter( $vars ){
        $vars[] = "noticia_page";
        $vars[] = "from";
        $vars[] = "to";
        $vars[] = "valor";
        $vars[] = "code";
        return $vars;
}
add_filter( 'query_vars', 'add_query_vars_filter' );

function title_limite($maximo) {
        $title = get_the_title();

        if ( strlen($title) > $maximo ) {
                $continua = '...';
        }

        $title = mb_substr( $title, 0, $maximo, 'UTF-8' );
        echo $title.$continua;
}

function widgets_novos_widgets_init(){
        register_sidebar( array(
                                'name' => 'Rodape 1',
                                'id' => 'rodape_widgets',
                                'before_title' => '<h2>',
                                'after_title' => '</h2>',
                               ) );
        register_sidebar( array(
                                'name' => 'Rodape 2',
                                'id' => 'rodape_widgets2',
                                'before_title' => '<h2>',
                                'after_title' => '</h2>',
                               ) );
}
add_action( 'widgets_init', 'widgets_novos_widgets_init' );

function setPostViews($postID) {
        $countKey = 'post_views_count';
        $count = get_post_meta($postID, $countKey, true);

        if($count=='') {
                $count = 0;
                delete_post_meta($postID, $countKey);
                add_post_meta($postID, $countKey, '0');
        } else {
                $count++;
                update_post_meta($postID, $countKey, $count);
        }
}

function clQuote($currency) {
        $apiUrl = file_get_contents("http://apilayer.net/api/live?access_key=cb8a60847541bdb828ff4274697cdc36&currencies=BRL&source=$currency&format=1");
        $apiData = json_decode($apiUrl, true);
        $currencyQuote = $apiData["quotes"]["{$currency}BRL"];
        $currencyValue = number_format($currencyQuote, 2, ',', '.');

        return $currencyValue;
}

function clQuoteTable($currency) {
        $end = date('Y-m-d', strtotime('-1 day'));
        $start = date('Y-m-d', strtotime('-11 days'));

        $apiUrl = file_get_contents("http://apilayer.net/api/timeframe?access_key=cb8a60847541bdb828ff4274697cdc36&start_date=$start&end_date=$end&currencies=BRL&source=$currency&format=json");
        $apiData = json_decode($apiUrl, JSON_PRETTY_PRINT);
        $quoteList = array_reverse($apiData['quotes']);

        foreach ($quoteList as $d => $value) {
                $rawDate = strtotime($d);
                $quoteDate = date('d/m/Y', $rawDate);

                echo "<tr>";
                echo "<td>" . $quoteDate . "</td>";
                echo "<td>" . number_format(current($value), 2, ',', '.') . "</td>";
                echo "</tr>";
        }
}

function alpha($crypto) {
        $cryptoCurrencyUrl = file_get_contents("https://min-api.cryptocompare.com/data/price?fsym=$crypto&tsyms=BRL");
        $cryptoCurrencyData = json_decode($cryptoCurrencyUrl, true);
        $cryptoCurrencyQuote = $cryptoCurrencyData['BRL'];
        $cryptoCurrencyValue = number_format($cryptoCurrencyQuote, 2, ',', '.');

        return $cryptoCurrencyValue;
}
