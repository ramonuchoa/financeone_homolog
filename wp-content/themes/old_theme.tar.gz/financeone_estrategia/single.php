<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package financeone
 */

get_header();
	$margin = '';

                if ( has_category( 'sem-sidebar', get_the_ID() ) ) {
                        $class = "col-md-9 col-xs-12";
			$margin = 'style="margin-top: 120px;"';
                } else {
                        $class = "col-md-6 col-xs-12 col-sm-push-3";
                }
?>
<section id="principal" class="container-fluid" <?php echo $margin; ?>>
        <div class="<?php echo $class; ?>" id="ultimas-noticias">
                <div class="row">
                        <div class="col-md-12 reset-padding">
                                <?php
                                        while ( have_posts() ) : the_post();
                                                get_template_part( 'template-parts/content', get_post_format() );
                                                setPostViews(get_the_ID());
                                        endwhile;
                                ?>
                        </div>
			<?php the_post_navigation(); ?>
                </div>
		<?php get_template_part('template-parts/relatedPostsBox'); ?>
        </div>
        <?php
                if ( has_category( 'sem-sidebar', get_the_ID() ) ) {
                        get_template_part('template-parts/right');
                } else {
                        get_template_part('template-parts/left');
                        get_template_part('template-parts/right');
                }
        ?>
</section>
<?php get_footer(); ?>
