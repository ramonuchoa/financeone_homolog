<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 *
 *
 * Template Name: Euro Hoje
 */

get_header(); ?>
<section id="principal" class="container-fluid">
        <div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
                <div class="row">
                        <h1><?php the_title(); ?></h1>
                </div>

                <div class="row dolar-hoje">&euro;1,00 vale R$<?php echo clQuote("EUR"); ?> hoje</div>

                <div class="row">
                        <p><strong>Finance One</strong> tem a <strong>Cotação do Euro</strong> (EUR, €) sempre atualizada para que você tome as melhores decisões.</p>
                        <p>O <strong>Euro</strong> (EUR, €) é a moeda oficial da zona Euro. A moeda também é usada oficialmente pelas instituições da União Européia, por quatro outros países da Europa e unilateralmente por outros dois. Ela é forte e sua cotação é bem alta.</p>
                        <p>O <strong>preço do euro</strong> é mais procurado pelas pessoas que estão planejando <strong>viagens para a Europa</strong> seja a turismo ou negócios, que querem comprar produtos importados, trabalham com exportação e investidores.</p>
                        <p>Alterações pequenas no euro podem tornar mais caros ou baratos preços de produtos em lojas online e também podem influenciar no orçamento de viagens para alguns países da União Européia e outros países.</p>
                </div>

                <div class="row">
                        <h2>Os tipos de Euro</h2>
                        <p><strong>Euro comercial</strong> é utilizado na importação e exportação. Também é utilizado pelo governo para transações financeiras. É relacionada ainda a empréstimos para brasileiros no exterior.</p>
                        <p><strong>Euro turismo</strong> é o que compramos quando queremos ir ao exterior. As compras feitas fora do Brasil em países da zona Euro são convertidos com a taxa do euro turismo.</p>
                        <p><strong>Euro paralelo</strong> é comercializado por pessoas e empresas sem autorização do Banco Central.</p>
		</div>

		<div class="row">
                        <h2>Euro comercial - históricos</h2>

                        <table class="table">
                                <tr>
                                        <th>Data</th>
                                        <th>Valor</th>
                                </tr>
                                <?php echo clQuoteTable('EUR'); ?>
                        </table>
                </div>

                <div class="row">
                        <h2>Quais os impostos ao comprar Euro</h2>
                        <p>Ao comprar euros, paga-se IOF, Imposto sobre Operações Financeiras, de 1,1% sobre o valor da operação. Além de taxas administrativas da instituição. Já as operações no cartão de crédito, débito e pré-pago e cheques de viagem possuem alíquota de 6,38%.</p>
                </div>

                <div class="row">
                        <h2>Taxa de câmbio</h2>
                        <p>A taxa de câmbio é o preço de uma moeda em relação à outra. No caso, mostramos o câmbio do euro em relação ao real. Esse valor muda várias vezes ao dia, logo é bom que você sempre esteja atualizado da cotação do momento. As taxas variam na compra, na venda e de acordo com a instituição onde se compra a moeda.</p>
                </div>

                <div class="row">
                        <?php
                                $numerosParaCalcular = array(
                                        array('numero'=>1,'texto'=>'1€ (um euro)'),
                                        array('numero' => 2, 'texto' => '2€ (dois euros)'),
                                        array('numero' => 5, 'texto' => '5€ (cinco euros)'),
                                        array('numero' => 10, 'texto' => '10€ (dez euros)'),
                                        array('numero' => 25, 'texto' => '25€ (vinte e cinco euros)'),
                                        array('numero' => 50, 'texto' => '50€ (cinquenta euros)'),
                                        array('numero' => 100, 'texto' => '100€ (cem euros)'),
                                        array('numero' => 500, 'texto' => '500€ (quinhentos euros)'),
                                        array('numero' => 1000, 'texto' => '1000€ (mil euros)'),
                                        array('numero' => 10000, 'texto' => '10000€ (dez mil euros)'),
                                );
                                $value = floatval(str_replace(",", "", clQuote('EUR'))) / 100;
                        ?>

			<h2>Tabela de valores em Euro convertidos em Real</h2>

			<table class="table">
                                <tr>
                                        <th>Euro</th>
                                        <th>Real</th>
                                </tr>

                                <?php foreach ($numerosParaCalcular as $key => $numero) :?>

                                <tr>
                                        <td><?php echo $numero['texto']; ?></td>
                                        <td><?php echo "R$ ".number_format(($numero['numero'] * $value), 2, ',', '.'); ?></td>
                                </tr>

                                <?php endforeach; ?>
                        </table>
                </div>
        </div>

        <?php
                get_template_part('template-parts/left');
                get_template_part('template-parts/right');
        ?>
</section>
<?php get_footer(); ?>
