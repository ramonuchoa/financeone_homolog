<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

 /*
 Template Name: Pagina noticias ultimas notícias
 */

get_header(); ?>
<section id="principal" class="container-fluid">
        <div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
                <div class="row">
                        <h1 class='entry-title'><?php the_title(); ?></h1>
                </div>

                <div id="box-noticia-resumida">
                        <?php
                                $args = array(
                                        'paged' => get_query_var( 'page' ),
                                        'posts_per_page'=> 20,
                                );

                                $query = new WP_Query($args);
                                if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();
					get_template_part('template-parts/postBox');
                		endwhile; else :
			?>
			<p><?php esc_html_e( 'Nada para mostar aqui.' ); ?></p>
                <?php endif; ?>
                </div>

                <div class="row">
                        <a href="<?php echo get_permalink(get_page_by_path('noticias')); echo ((get_query_var( 'page' ) == 0)  ? 2 : get_query_var( 'page' ) + 1); ?>" class="btn-silver">ver mais noticias</a>
                </div>
                <?php
                        get_template_part('template-parts/categoryBoard');
                        get_template_part('template-parts/newSection');
                ?>
        </div>

        <?php
                get_template_part('template-parts/left');
                get_template_part('template-parts/right');
        ?>
</section>
<?php get_footer(); ?>
