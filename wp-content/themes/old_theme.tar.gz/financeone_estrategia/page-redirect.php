<?php
    /* Template Name: Page Redirect */

    header("HTTP/1.1 301 Moved Permanently");
    header("Location: https://homolog.financeone.com.br");
?>
