<?php if(!is_page('ebook-gratuito-investidor-iniciante')): ?>
        <div class="ebookCtaBox row">
                <h2>Ebook do FinanceOne</h2>
                <img src="<?php bloginfo('template_directory'); ?>/img/Baixar-ebook-home.png" alt="Ebook gratuito investidor iniciante">
                <p>Quer investir mas n&atilde;o sabe como&#63; O Guia Completo do Investidor Iniciante traz os primeiros passos para voc&ecirc; come&ccedil;ar a investir e ganhar dinheiro&#33;</p>
                <a class="btn btn-warning" href="<?php echo site_url();?>/ebook-gratuito-investidor-iniciante/">BAIXAR AGORA&#33;</a>
        </div>
<?php endif ?>
