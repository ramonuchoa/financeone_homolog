<?php                   
        $ctaCategories = [
                'noticias-economia',                                                     
                'financas-pessoais',
                'indices-e-taxas',
                'noticias-internacionais',
                'noticias-mercado-cambial',
                'criptomoeda',
                'dolar',
                'euro',                                                                  
                'outras-moedas',                                                         
                'noticias-mercado-financeiro'                                            
        ];              
                                
        if ( in_category($ctaCategories) ) {                                             
?>                              
                        
<div class='ctaToConverter'>                                                             
        <h4 class='ctaConverterTitle'>Precisa converter&quest;</h4>                      
        <p class='ctaConverterContent'>A calculadora de convers&atilde;o do FinanceOne fornece os &uacute;ltimos valores cotados para diversas moedas. Acesse agora&excl;</p>
        <a class='ctaBtn' href='<?php echo site_url(); ?>/moedas/conversor-de-moedas/'>Converter agora</a>
</div>                                                                                   
        
<?php } ?>
