<div class="row un noticia-resumida">
        <?php
                if( has_post_thumbnail() ) {
                        $style = '';
                        $col = 'col-md-9';
                } else {
                        $style = 'display:none;';
                        $col = 'col-md-12';
                }
        ?>

        <div class="postThumb col-md-3 col-xs-12" style="<?php echo $style; ?>">
                <div class='postThumbBox' style='background-image: url("<?php the_post_thumbnail_url(); ?>");'></div>
        </div>

        <div class="<?php echo $col; ?> col-xs-12">
                <div class="data">
                        <?php the_time( get_option('date_format') ); ?>
                </div>

                <a href="<?php the_permalink(); ?>" class="title">
                        <?php the_title(); ?>
                </a>

                <p>
                        <?php
				if ( has_excerpt( $post->ID ) ) {
					the_excerpt();
				} else {
	                                $content = get_the_content();
        	                        $content = strip_tags($content);
                	                $resumo  = substr($content, 0, 150);

                        	        echo $resumo . "...";
				}
                        ?>
                </p>

                <a href="<?php the_permalink(); ?>" class="hidden-sm hidden-xs">Continuar lendo <span class="glyphicon glyphicon-chevron-right"></span></a>

                <?php get_template_part('template-parts/social-share'); ?>
        </div>
</div>
