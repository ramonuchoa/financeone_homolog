<div class="col-md-3 col-xs-12" id="videos">
        <?php
		get_template_part('template-parts/ebookBox');

		if ( !in_category('sem-sidebar') || is_home() ) :
	?>
                <div class="row">
                        <h2>Publicidade</h2>

			<br />
			<div class='dynaton-ads'>
				<!-- Aqui serão renderizados os anúncios -->
			</div>
			&nbsp;
			<a href="https://secure.afilio.com.br/tracker.php?banid=4457494&campid=40551;2586&siteid=47572" target="_blank"><img class='bannerAfilio' src="https://secure.afilio.com.br/banner.php?banid=4457494&campid=40551;2586&siteid=47572" border="0"></a>
			&nbsp;
			<a href="https://secure.afilio.com.br/tracker.php?banid=4460542&campid=40551;2815&siteid=47572" target="_blank"><img class='bannerAfilio' src="https://secure.afilio.com.br/banner.php?banid=4460542&campid=40551;2815&siteid=47572" border="0"></a>
			&nbsp;
			<a href="https://secure.afilio.com.br/tracker.php?banid=4450296&campid=40551;483&siteid=47572" target="_blank"><img class='bannerAfilio' src="https://secure.afilio.com.br/banner.php?banid=4450296&campid=40551;483&siteid=47572" border="0"></a>
			&nbsp;
			<a href="https://secure.afilio.com.br/tracker.php?banid=4431830&campid=40551;357&siteid=47572" target="_blank"><img class='bannerAfilio' src="https://secure.afilio.com.br/banner.php?banid=4431830&campid=40551;357&siteid=47572" border="0"></a>
			&nbsp;
			<a href="https://secure.afilio.com.br/tracker.php?banid=4456356&campid=40551;2605&siteid=47572" target="_blank"><img class='bannerAfilio' src="https://secure.afilio.com.br/banner.php?banid=4456356&campid=40551;2605&siteid=47572" border="0"></a>
			&nbsp;
			<?php echo do_shortcode('[the_ad id="65935"]'); ?>
                </div>
        <?php endif; ?>
        <div class="row">
                <h2>Guias</h2>
        </div>

        <div class="row" id="box-guias">
                <br />

                <ul>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/guias/restituicao-irpf/">Lembrete de restitui&ccedil;&atilde;o de IRPF 2017 </a></li>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/guias/tabela-irpf/">Tabela imposto de renda 2017</a></li>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/guias/como-consultar-o-fgts/">Como consultar o FGTS</a></li>
                </ul>
        </div>
        <!-- end of guias -->

        <div class="row">
                <h2>Calculadoras</h2>
        </div>

        <div class="row" id="box-guias">
                <br />

                <ul>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/calculadoras/calculo-de-rescisao-trabalhista/">Rescis&atilde;o trabalhista</a></li>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/calculadoras/calculo-de-salario-liquido/">Sal&aacute;rio l&iacute;quido</a></li>
                        <li><span class="glyphicon glyphicon-link" aria-hidden="true"></span>&nbsp;<a href="<?php echo site_url(); ?>/calculadoras/calculo-de-hora-extra/">Hora extra</a></li>
                </ul>
        </div>
        <!-- end of calculadoras -->
</div>
