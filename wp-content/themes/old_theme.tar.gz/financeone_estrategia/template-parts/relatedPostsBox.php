<?php
	$relatedPostsArgs = array(
		'posts_per_page' => 5,
		'post__not_in' => array( get_the_ID() ),
		'no_found_rows' => true
	);

	$cats = wp_get_post_terms( get_the_ID(), 'category' );
	$cats_ids = array();

	foreach( $cats as $relatedPostCat ) {
		$cats_ids[] = $relatedPostCat->term_id;
	}

	if ( ! empty( $cats_ids ) ) {
		$relatedPostsArgs['category__in'] = $cats_ids;
		echo '<h2>Posts relacionados</h2>';
	}

	$relatedPostsQuery = new wp_query( $relatedPostsArgs );

	foreach( $relatedPostsQuery->posts as $post ) : setup_postdata( $post );
		get_template_part('template-parts/postBox');
	endforeach;
	wp_reset_postdata();
?>
