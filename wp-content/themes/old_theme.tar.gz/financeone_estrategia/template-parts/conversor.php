<?php
/*
Template Name: Conversor
*/
error_reporting(E_ALL);
ini_set('display_errors', 'on');
$valor   = $_GET['valor'];
$from    = $_GET['from'];
$to      = $_GET['to'];
$code    = $_GET['code'];

$valor_convertido = conversao($valor,$from,$to);
 
echo '('.$code.') '.($valor_convertido);
?>
