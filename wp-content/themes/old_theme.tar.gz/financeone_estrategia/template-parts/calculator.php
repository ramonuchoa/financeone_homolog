
	<div id="conversor-de-moeda" class="hidden-md hidden-lg container-fluid">
		<div class="container">

				<div class="row">
					<div class="col-md-12">
						<span class="title">Conversor de Moeda</span>
					</div>
				</div>

				<div class="row">
					<div class="col-md-1">
						 <div class="navbar-form navbar-left">
									<div class="form-group">
										<label for="valor">Valor:</label><br>
										<input type="text" name="valor" class="form-control" value="1">
									</div>
							</div>
					</div>
					<div class="col-md-4">
						 <div class="navbar-form navbar-left">
									<div class="form-group">
										<label for="da-moeda">Da moeda:</label><br>
										<?php //debug(get_moedas()); ?>
										<?php echo selectDePaises('da-moeda',get_moedas()); ?>
									</div>
							</div>
					</div>
					<div class="col-md-1">
						<span class="glyphicon glyphicon-sort center hidden-sm hidden-xs inverter-moedas"></span>
					</div>
					<div class="col-md-4">
						 <div class="navbar-form navbar-left">
									<div class="form-group">
										<label for="para-a-moeda">Para a moeda:</label><br>
							<?php echo selectDePaises('para-a-moeda',get_moedas()); ?>
									</div>
							</div>
					</div>
					<div class="col-md-2">
						 <div class="navbar-form navbar-left">
									<div class="form-group">
										<span>Valor Convertido:</span><br>
								<span class="valor-convertido">R$ 0,00</span>
									</div>
							</div>
					</div>
				</div>

		</div>
	</div>
