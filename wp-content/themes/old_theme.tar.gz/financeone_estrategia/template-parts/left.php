<div class="col-md-3 col-xs-12 col-sm-pull-6" id="mais-lidos">
	<div class="row">
		<h2>Mais lidos</h2>
	</div>

	<?php
		query_posts('meta_key=post_views_count&orderby=meta_value_num&order=DESC&posts_per_page=5');
		if (have_posts()) : while (have_posts()) : the_post();
	?>

	<div class="row mais-lidos-info">
		<div class="col-md-12 col-xs-11">
			<?php
				$content = get_the_content();
				$content = strip_tags($content);
				$resumo = substr($content, 0, 100);
			?>

			<a class="title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>

			<div class="content"> <?php echo $resumo; ?> ...</div>

			<a href="<?php the_permalink(); ?>" class="hidden-sm hidden-xs">Continuar lendo <span class="glyphicon glyphicon-chevron-right"></span></a>
		</div>

		<div class="visible-xs visible-sm col-xs-1 arrow-left"><span class="glyphicon glyphicon-chevron-right center"></span></div>
	</div>

	<?php
		endwhile;
		endif;
		wp_reset_query();

		$pageList = [
			'conversor-de-moedas',
			'dolar-hoje',
			'euro-hoje',
			'bitcoin-hoje',
			'cotacoes-do-dolar',
			'cotacoes-do-euro'
		];

        	if ( is_page($pageList) ) :
	?>

		<div class="row">
			<h2>Transfer&ecirc;cia internacional</h2>
		</div>
                <div class='row'>
                        <div id="tw-calc-widget"><!-- tw calculator will be rendered here --></div>
                </div>

        <?php endif ?>
</div>
