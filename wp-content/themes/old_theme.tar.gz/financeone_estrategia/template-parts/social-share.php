<div class="social-icons">
  <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/img/social-icons/facebook.png" alt=""></a>
  <a href="https://twitter.com/share?url=<?php the_permalink(); ?>" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/img/social-icons/twitter.png" alt=""></a>
  <a class="hidden-md hidden-lg" href='whatsapp://send?text=<?php the_permalink(); ?>'>
  	<img src="<?php bloginfo('template_directory'); ?>/img/social-icons/whatsapp.png" alt="">
  </a>
</div>
