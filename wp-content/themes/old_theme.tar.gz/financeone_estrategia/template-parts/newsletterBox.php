<div class='newsletterCta'>
        <h4 class='newsletterCtaTitle'>Receba novidades</h4>
        <p class='newsletterCtaContent'>Cadastre-se em nossa newsletter para receber novidades em seu email.</p>
        <?php echo do_shortcode( '[contact-form-7 id="72147" title="Newsletter"]' ); ?>
</div>
