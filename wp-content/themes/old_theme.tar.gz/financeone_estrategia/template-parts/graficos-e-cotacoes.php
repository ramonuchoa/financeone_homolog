<section class="liveExchange">
    <h2>Gr&aacute;ficos e cota&ccedil;&otilde;es de hoje</h2>
    <div class='stocks'>
        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/dolar.png">
            <span class="title">D&oacute;lar</span>
            <span class="valor">R$<?php echo clQuote("USD"); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/euro.png">
            <span class="title">Euro</span>
            <span class="valor">R$<?php echo clQuote("EUR"); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/libra.png">
            <span class="title">Libra</span>
            <span class="valor">R$<?php echo clQuote("GBP"); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/peso.png">
            <span class="title">Peso</span>
            <span class="valor">R$<?php echo clQuote("ARS"); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/bitcoin.png">
            <span class="title">Bitcoin</span>
            <span class="valor">R$<?php echo clQuote("BTC"); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/litecoin.png">
            <span class="title">Litecoin</span>
            <span class="valor">R$<?php echo alpha('LTC'); ?></span>
        </div>

        <div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/ripple.png">
            <span class="title">Ripple</span>
            <span class="valor">R$<?php echo alpha('XRP'); ?></span>
        </div>

	<div>
            <img alt="" src="<?php bloginfo('template_directory'); ?>/img/moedas/ethereum.png">
            <span class="title">Ethereum</span>
            <span class="valor">R$<?php echo alpha('ETH'); ?></span>
        </div>
    </div>
</section>
