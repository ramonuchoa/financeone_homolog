<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

        $pageList = [
                'contato',
                'quem-somos'
        ];
?>
<section id="principal" class="container-fluid">
<?php
        if ( is_page ($pageList) ) {
                $class = "col-md-9 col-xs-12";
        } else {
                $class = "col-md-6 col-xs-12 col-sm-push-3";
        }
?>
        <div class="<?php echo $class; ?>" id="ultimas-noticias">
                <div class="row" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                </div>

                 <div class="row">
                        <div class="col-md-12 reset-padding">
                                <?php
                                        the_content();

                                        wp_link_pages( array(
                                                'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'financeone' ),
                                                'after'  => '</div>',
                                        ) );
                                ?>
			</div>
                </div>
                <div class="row">
                        <div class="col-md-12">
                                <?php if ( get_edit_post_link() ) : ?>
                                        <?php
                                                edit_post_link(
                                                        sprintf(
                                                                /* translators: %s: Name of current post */
                                                                esc_html__( 'Edit %s', 'financeone' ),
                                                                the_title( '<span class="screen-reader-text">"', '"</span>', false )
                                                        ),
                                                        '<span class="edit-link">',
                                                        '</span>'
                                                );
                                        ?>
                                <?php endif; ?>
                                <?php
                                if ( is_page('cotacoes-do-real-e-outras-moedas') || is_page('cotacoes-do-euro') || is_page('cotacoes-do-dolar') ) {
                                        $ehPagina = ( is_page('cotacoes-do-euro') )                             ? 'euro' : '' ;
                                        $ehPagina = ( is_page('cotacoes-do-dolar') )                            ? 'dolar' : $ehPagina ;
                                        $ehPagina = ( is_page('cotacoes-do-real-e-outras-moedas') ) ? 'real' : $ehPagina ;

                                        if ($ehPagina == 'real') {
                                                $catA = ''; $catB = '';
                                                query_posts('category_name=real&posts_per_page=1&pageg=1');
                                                if (have_posts()) {
                                                        while (have_posts()) {
                                                                the_post();
                                                                $category = get_the_category();
                                                                $catA = $category[0]->cat_ID;
                                                                break;
                                                        }
                                                }
                                                query_posts('category_name=outras-moedas&posts_per_page=1&pageg=1');
                                                if (have_posts()) {
                                                        while (have_posts()) {
								the_post();
                                                                $category = get_the_category();
                                                                $catB = $category[0]->cat_ID;
                                                                break;
                                                        }
                                                }
                                                $ehPagina = array($catA, $catB);
                                                $news_query_args = array(
                                                        'paged' => 1,
                                                        'orderby' => 'date',
                                                        'category__in' => $ehPagina,
                                                        'order' => 'DESC',
                                                        'showposts' => 4
                                                );
                                                query_posts($news_query_args);
                                        } else {
                                                $news_query_args = array(
                                                        'paged' => 1,
                                                        'orderby' => 'date',
                                                        'category_name' => $ehPagina,
                                                        'order' => 'DESC',
                                                        'showposts' => 4
                                                );
                                                query_posts($news_query_args);
                                        }
                                        if ( have_posts() ) :
                                        ?>

                                <?php endif;
                                } else { echo "<!-- nao foi -->"; }
                                ?>
                        </div>
                </div>

        </div>

<?php
	if ( is_page($pageList) ) {
                get_template_part('template-parts/right');
        } else {
                get_template_part('template-parts/left');
                get_template_part('template-parts/right');
        }
?>
</section>
