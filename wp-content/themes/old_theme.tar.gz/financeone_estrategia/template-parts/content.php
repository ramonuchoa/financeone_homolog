<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 */

?>

<article style="border: 1px solid #c4c4c4;padding: 15px;" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php
		if ( is_single() ) :
			// the_post_thumbnail('noticia-interna');
			the_title( '<h1 class="entry-title">', '</h1>' );
		else :
			the_title( '<h1 class="seo-hidden">', '</h1>' );
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) : ?>
			<div class="entry-meta">
				<p>
					<?php
						echo 'Escrito por: ';
							the_author_link();
						echo ' em ';
							the_time( get_option( 'date_format' ) );
					?>
				</p>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php
			$content = get_the_content();
			$content = apply_filters('the_content', $content);

			echo $content;

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'financeone' ),
				'after'  => '</div>',
			) );
		?>
	</div><!-- .entry-content -->

	<?php
		if ( comments_open() || get_comments_number() ) :
			comments_template();                                            
		endif;

		get_template_part('template-parts/ctaBox');
		get_template_part('template-parts/newsletterBox');

		if ( !in_category('sem-sidebar') || is_home() ) :
	?>
		<div class="row banners-google">
			<div class="col-md-6">
				<?php echo do_shortcode('[the_ad id="72475"]'); ?>
			</div>
			<div class="col-md-6">
				<?php echo do_shortcode('[the_ad id="72475"]'); ?>
			</div>
		</div>
	<?php endif; ?>
</article><!-- #post-## -->
