<div class='row'>
        <h2>Categorias</h2>
        <div class="categoriesList">
                <?php
                        wp_list_categories( array (
                                'title_li' => '',
                                'exclude' => array( 1, 38, 40, 1234 ),
                                'echo' => 1,
                                'depth' => 1
                        ) );
                ?>
        </div>
</div>
