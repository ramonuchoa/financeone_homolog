var button = document.querySelector('#topMenuBtn');
var menu = document.querySelector('#menu-menu');

button.addEventListener('click', function () {
	if ( !menu.hasAttribute('style') || menu.style.left == '-120vw' ) {
		menu.style.left = '-20px';
		button.innerHTML = '<i class="fas fa-times"></i>';
	} else {
		menu.style.left = '-120vw';
		button.innerHTML = '<i class="fas fa-bars"></i>';
	}
});

var searchBtn = document.querySelector('#formBtn');
var searchForm = document.querySelector('#searchFormBox');

searchBtn.addEventListener('click', function (){
	if (searchForm.style.left == '0px') {
		searchForm.style.left = '-100vw';
		searchBtn.innerHTML = '<i class="fas fa-search"></i>';
	} else {
		searchForm.style.left = '0';
		searchBtn.innerHTML = '<i class="fas fa-times"></i>';
	}
});
