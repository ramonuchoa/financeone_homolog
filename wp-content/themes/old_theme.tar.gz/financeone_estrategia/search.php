<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package financeone
 */

get_header(); ?>
<section id="principal" class="container-fluid">
	<div class="col-md-6 col-xs-12 col-sm-push-3" style="padding: 0 0 0 41px;">
		<div class="row">
			<div class="col-md-12 reset-padding">
				<?php if ( have_posts() ) : ?>
					<h1 class="page-title"><?php printf( esc_html__( 'Resultados encontrados para: %s', 'financeone' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
					<?php
						/* Start the Loop */
						while ( have_posts() ) : the_post();
							/**
							  * Run the loop for the search to output the results.
							  * If you want to overload this in a child theme then include a file
							  * called content-search.php and that will be used instead.
							  */
							get_template_part( 'template-parts/content', 'search' );
						endwhile;
							the_posts_navigation();
						else :
							get_template_part( 'template-parts/content', 'none' );
					endif;
				?>
			</div>
		</div>

		<div class="row">
			<hr>
		</div>
	</div>

	<?php
		get_template_part( 'template-parts/left');
		get_template_part( 'template-parts/right');
	?>
</section>
<?php get_footer(); ?>
