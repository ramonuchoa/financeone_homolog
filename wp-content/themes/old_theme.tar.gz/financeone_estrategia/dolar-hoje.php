<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package financeone
 * Template Name: Dólar Hoje
 *
 */

get_header(); ?>
<section id="principal" class="container-fluid">
	<div class="col-md-6 col-xs-12 col-sm-push-3" id="ultimas-noticias">
		<div class="row">
			<h1><?php the_title(); ?></h1>
		</div>

		<div class="row dolar-hoje">US$1,00 vale R$<?php echo clQuote("USD"); ?> hoje</div>

		<div class="row">
			<p><strong>Finance One</strong> tem a Cotação do Dólar sempre atualizada para que você tome as melhores decisões.</p>
			<p>O <strong>valor do dólar</strong> hoje é de caráter informativo, sendo mais próximo do <strong>dólar comercial</strong> e não do <strong>dólar turismo</strong>. Em caso de flutuações na cotação do dólar, o <strong>Banco Central</strong> (BC, BACEN ou BCB) pode intervir nas bolsas na tentativa de estabilizar a inflação e o Real.</p>
		</div>

		<div class="row">
			<h2>Os tipos de dólar</h2>

			<p><strong>Dólar comercial</strong> é utilizado para transações comerciais entre dois bancos, instituições financeiras e grandes empresas. Existem cotações diferentes de compra e venda. Essa diferença representa o lucro bruto do banco responsável pela intermediação das negociações.</p>
			<p><strong>Dólar turismo</strong> é utilizado nas negociações de moeda estrangeira entre bancos e pessoas físicas. Normalmente com o objetivo de viajar e comprar no exterior.</p>
			<p><strong>Dólar paralelo</strong> é vendido por pessoas e empresas sem autorização do Banco Central, logo é ilegal. É usado no cálculo de imposto de compras no Paraguai.</p>
			<p><strong>Dólar PTAX</strong> é a taxa de câmbio calculada com a média das taxas praticadas pelo mercado durante o dia e divulgada pelo BC.</p>
		</div>

		<div class="row">
			<h2>Dólar comercial - históricos</h2>

			<table class="table">
				<tr>
					<th>Data</th>
					<th>Valor</th>
				</tr>
				<?php echo clQuoteTable("USD"); ?>
			</table>
		</div>

		<div class="row">
			<h2>Impostos na compra ou utilização de dólar</h2>
			<p>Existe um imposto para operações com dólar e outras moedas estrangeiras. É o IOF, Imposto sobre Operações Financeiras. No ato de compra da moeda, o imposto é 1,1% do valor adquirido. Nas transações do cartão de débito, de crédito e pré-pago e cheques de viagem, o valor é de 6,38%.</p>
		</div>

		<div class="row">
			<h2>Porque a cotação que compramos é diferente das divulgadas pelo Banco Central e outros meios</h2>
			<p>A cotação divulgada pelo Banco Central (PTAX) é uma referência e não precisa ser usada pelas instituições que vendem. Os meios de comunicação divulgam cotações usadas na venda de moeda para turismo (dólar turismo) e em transações comerciais (dólar comercial), além de poderem cobrar suas taxas de serviços.</p>
		</div>

		<div class="row">
		<?php
		$numerosParaCalcular = array(
			array('numero' => 1, 'texto' => 'US$ 1 (um dólar)'),
			array('numero' => 2, 'texto' => 'US$ 2 (dois dólares)'),
			array('numero' => 5, 'texto' => 'US$ 5 (cinco dólares)'),
			array('numero' => 10, 'texto' => 'US$ 10 (dez dólares)'),
			array('numero' => 25, 'texto' => 'US$ 25 (vinte e cinco dólares)'),
			array('numero' => 50, 'texto' => 'US$ 50 (cinquenta dólares)'),
			array('numero' => 100, 'texto' => 'US$ 100 (cem dólares)'),
			array('numero' => 500, 'texto' => 'US$ 500 (quinhentos dólares)'),
			array('numero' => 1000, 'texto' => 'US$ 1000 (mil dólares)'),
			array('numero' => 10000, 'texto' => 'US$ 10000 (dez mil dólares)'),
		);

		$value = floatval(str_replace(",", "", clQuote('USD'))) / 100;
		?>

			<h2>Tabela de Valores em Dólar Convertidos em Real</h2>

			<table class="table">
				<tr>
					<th>Dólar</th>
					<th>Real</th>
				</tr>

				<?php foreach ($numerosParaCalcular as $key => $numero) :?>

				<tr>
					<td><?php echo $numero['texto']; ?></td>
					<td><?php echo "R$ ". number_format(($numero['numero'] * $value), 2, ',', '.'); ?></td>
				</tr>

				<?php endforeach; ?>
			</table>
		</div>
	</div>

	<?php
		get_template_part('template-parts/left');
		get_template_part('template-parts/right');
	?>

</section>

<?php get_footer(); ?>
