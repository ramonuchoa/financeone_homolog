<div class="coluna-box">
  <p class="subtitulo-box">Cotação por data:</p>
  <div id="box-cotacoes" class="cotacao-poupanca">
    <table>
      <tr>
        <th>Data</th>
        <th>Rendimento</th>
      </tr>
      <tr>
        <td>{data}</td>
        <td>{rend}</td>
      </tr>
    </table>
  </div>
  <p><a href="{action}">Voltar</a></p>
</div>