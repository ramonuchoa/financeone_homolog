<div class="coluna-box">
	<p class="subtitulo-box">Cotação por período:</p>

	<div id="box-cotacoes">
		<table class="nomargin">
			<tr>
				<th>Data</th>
				<th>Compra</th>
				<th>Venda</th>
			</tr>
			{lista}
		</table>
	</div>

	<p class="nomargin"><a href="{action}">Voltar</a></p>
</div>
