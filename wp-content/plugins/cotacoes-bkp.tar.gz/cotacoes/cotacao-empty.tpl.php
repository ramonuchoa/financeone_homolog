Não existem cotações a serem exibidas na data informada. Digite outros dados de pesquisa e tente novamente.
<p><a href="{action}">Voltar</a></p>