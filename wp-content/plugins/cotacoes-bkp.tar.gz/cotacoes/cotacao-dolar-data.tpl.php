<div class="coluna-box">
  <p class="subtitulo-box">Cotação por data:</p>
  <div id="box-cotacoes">
    <table>
      <tr>
        <th>Data</th>
        <th>Compra</th>
        <th>Venda</th>
      </tr>
      <tr>
        <td>{data}</td>
        <td>R$ {cota-compra}</td>
        <td>R$ {cota-venda}</td>
      </tr>
    </table>
  </div>
  <p><a href="{action}">Voltar</a></p>
</div>