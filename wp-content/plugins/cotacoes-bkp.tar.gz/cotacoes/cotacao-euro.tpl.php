<!--[if IE]><script language="javascript" type="text/javascript" src="{src}/js/excanvas.min.js"></script><![endif]-->
<script language="javascript" type="text/javascript" src="{src}/js/jquery.flot.min.js"></script>

<script id="source" language="javascript" type="text/javascript">
  jQuery(document).ready(function($) {  
    function grafico(dados, el)
    {
      var g = new Array;
      
      options = {
        xaxis: { ticks: [] },
        yaxis: { ticks: [] },
        grid:  { backgroundColor: '#ffffcc', borderColor: '#ffcc66' }
      };
      
      for (i=0; i<dados.length;i++) {
        g[i] = [i+1, dados[i]];
      }
      
      jQuery.plot(jQuery(el), [{ color: '#ff0000', data : g }], options);
    }
    
    grafico([{grafico7dados}], '#grafico-7');
    grafico([{grafico30dados}], '#grafico-30');
    grafico([{grafico100dados}], '#grafico-100');
    grafico([{grafico365dados}], '#grafico-365');
    
    $('input[name="dia"], input[name="mes"], input[name="ano"], input[name="dia_de"], input[name="mes_de"], input[name="ano_de"], input[name="dia_ate"], input[name="mes_ate"], input[name="ano_ate"], ').keyup(function(){
      var s = new String($(this).val());
    	s = s.replace(/\D/g,'');
    	$(this).val(s);
    });
  });
</script>

{box}

<p style="font-size: 14px;">As cotações acima são baseadas no valor de venda do Banco Central Brasileiro. Os valores devem ser utilizados SOMENTE para uma "BASE" . Não devem ser utilizados para venda de produtos, câmbio e afins.</p>


<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
    <h2>Gráficos do Euro</h2>
  </div>
</div>

<style type="text/css">
  #Graficos p{
    font-size: 14px;
    color: #000;
    margin-left: 10px;
  }
</style>
<div id="Graficos" style="overflow: hidden;">
  <div class="row">
    <div class="col-md-4">
      <div id="grafico-7" style="height:70px;"></div>
      <p class="grafico-variacao">
        <span class="alta left" style=" font-size: 12px; float: left; " title="Maior alta no período">Maior Alta<br>{grafico7alta}</span>
        <span class="baixa right" style=" font-size: 12px; float: right; " title="Maior baixa no período">Maior Baixa<br>{grafico7baixa}</span>
      </p>
      <p class="grafico-desc" style=" width: 100%; height: 20px; float: left; text-align: center; ">Últimos 7 dias</p>
    </div>
    <div class="col-md-4">
      <div id="grafico-30" style="height:70px;"></div>
      <p class="grafico-variacao">
        <span class="alta left" style=" font-size: 12px; float: left; " title="Maior alta no período">Maior Alta<br>{grafico30alta}</span>
        <span class="baixa right" style=" font-size: 12px; float: right; " title="Maior baixa no período">Maior Baixa<br>{grafico30baixa}</span>
      </p>
      <p class="grafico-desc" style=" width: 100%; height: 20px; float: left; text-align: center; ">Últimos 30 dias</p>
    </div>
    <div class="col-md-4">
      <div id="grafico-100" style="height:70px;"></div>
      <p class="grafico-variacao">
        <span class="alta left" style=" font-size: 12px; float: left; " title="Maior alta no período">Maior Alta<br>{grafico100alta}</span>
        <span class="baixa right" style=" font-size: 12px; float: right; " title="Maior baixa no período">Maior Baixa<br>{grafico100baixa}</span>
      </p>
      <p class="grafico-desc" style=" width: 100%; height: 20px; float: left; text-align: center; ">Últimos 100 dias</p>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div id="grafico-365" style="height:110px;"></div>
      <p class="grafico-variacao">
        <span class="alta left" style=" font-size: 12px; float: left; " title="Maior alta no período">Maior Alta<br>{grafico365alta}</span>
        <span class="baixa right" style=" font-size: 12px; float: right; " title="Maior baixa no período">Maior Baixa<br>{grafico365baixa}</span>
      </p>
      <p class="grafico-desc top" style=" width: 100%; height: 20px; float: left; text-align: center; ">Últimos 365 dias</p>
    </div>
  </div>
</div>